using UnityEngine.Localization.Settings;
using UnityEngine;

public class LanguageSelector : MonoBehaviour
{
    public void SetEnglish() //cambia el idioma seleccionado a ingl�s
    {
        LocalizationSettings.SelectedLocale = LocalizationSettings.AvailableLocales.GetLocale("en");
    }

    public void SetSpanish() //cambia el idioma seleccionado a espa�ol
    {
        LocalizationSettings.SelectedLocale = LocalizationSettings.AvailableLocales.GetLocale("es");
    }
}
